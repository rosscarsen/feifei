rootProject.name = "camera_android_camerax"
